/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file event_patch.h
 * @brief Calls the patches of the game events when they start.
 */

#pragma once

#include "common.h"

namespace core {
class EventManager;
}

namespace core {

/// Calls the patches of a game event when it starts and at each frame.
class EventPatch {
  MAKE_SINGLETON(EventPatch)

public:
  static void Initialize();

private:
  static u32 MainEventLoopHook(EventManager* manager);
  static void OnUpdate(uptr vtable);
  static void OnLoad(uptr vtable);
};

} // namespace core
