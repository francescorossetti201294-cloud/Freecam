/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file evolution_table.h
 * @brief The evolution table that the game loaded.
 */

#pragma once

#include "core/types.h"
#include "pokemon/constant/species.h"
#include "pokemon/native/evolution_data.h"

namespace pokemon {

/// The evolution data that the game loaded for one species.
struct EvolutionTable {
  uptr vtable;
  SpeciesId species;
  u16 _0;
  EvolutionData* data;
};

} // namespace pokemon
