/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file item_data.h
 * @brief The data of one item.
 *
 * @see docs/tutorials/11-change-items-and-shops.md
 */

#pragma once

#include "common.h"
#include "pokemon/constant/item.h"
#include "core/native/game_manager.h"
#include "pokemon/address.h"

namespace pokemon {
/// The data of one item: price, effects, pockets...
struct ItemData {
  /// Loads the data of an item.
  INLINE ItemData(const ItemId id) {
    core::GameFunction<void(ItemData*, ItemId, void*)>::Call(
        address::kItemDataInitialize, this, id,
        core::GameManager::GetInstance().GetSystemHeap());
  }

  /// Writes the name of the item.
  INLINE void GetName(String* str) {
    core::GameFunction<void(ItemData*, String*, void*)>::Call(
        address::kItemDataGetName, this, str,
        core::GameManager::GetInstance().GetSystemHeap());
  }

  u16 price; ///< The price in a Poké Mart.
  u8 hold_effect; ///< The effect when a Pokémon holds the item.
  u8 power;

  u8 pluck_effect;
  u8 fling_effect;
  u8 fling_power; ///< The power of Fling with this item.
  u8 natural_gift_power;

  u16 natural_gift_type : 5;
  u16 is_key_item : 1;
  u16 registered_button : 1;
  u16 overworld_pocket : 4; ///< The pocket of the Bag.
  u16 battle_pocket : 5; ///< The pocket of the Bag in battle.
  u8 overworld_function; ///< The effect when the player uses the item outside of a battle.
  u8 battle_function; ///< The effect when the player uses the item in battle.

  bool use_on_pokemon; ///< true: the player uses the item on a Pokémon.
  u8 item_type;
  u8 battle_hold_consume : 4;
  u8 use_no_consume : 4;

  u8 sort_number;

  u8 cure_sleep : 1;
  u8 cure_poison : 1;
  u8 cure_burn : 1;
  u8 cure_freeze : 1;
  u8 cure_paralysis : 1;
  u8 cure_confusion : 1;
  u8 cure_infatuation : 1;
  u8 guard_stat_stages : 1;

  u8 revive : 1;
  u8 revive_all : 1;
  u8 level_up : 1;
  u8 evolve : 1;
  u8 raise_attack : 4;

  u8 raise_defense : 4;
  u8 raise_sp_atk : 4;

  u8 raise_sp_def : 4;
  u8 raise_speed : 4;

  u8 raise_accuracy : 4;
  u8 raise_critical_hit : 2;
  u8 use_pp_up : 1;
  u8 use_pp_max : 1;

  u8 restore_pp : 1;
  u8 restore_all_pp : 1;
  u8 restore_hp : 1;
  u8 raise_hp_ev : 1;
  u8 raise_attack_ev : 1;
  u8 raise_defense_ev : 1;
  u8 raise_speed_ev : 1;
  u8 raise_sp_atk_ev : 1;

  u8 raise_sp_def_ev : 1;
  u8 ev_limit_control : 1;
  u8 friendship_mod_1 : 1;
  u8 friendship_mod_2 : 1;
  u8 friendship_mod_3 : 1;

  u8 _0 : 3;

  s8 hp_ev_value;
  s8 attack_ev_value;
  s8 defense_ev_value;
  s8 speed_ev_value;
  s8 sp_atk_ev_value;
  s8 sp_def_ev_value;
  u8 hp_restore_value;
  u8 pp_restore_value;
  s8 friendship_value_1;
  s8 friendship_value_2;
  s8 friendship_value_3;

  u8 _1[2];

  /// The game uses 32 bits for the item. The id is in the 16 low bits. The 16
  /// high bits are zero.
  ItemId id;
  u16 _2;
};
} // namespace pokemon
