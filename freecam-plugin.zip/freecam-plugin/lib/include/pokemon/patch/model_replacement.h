/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file model_replacement.h
 * @brief Lets a product change the look of a Pokémon model.
 *
 * @see docs/tutorials/10-replace-models.md
 */

#pragma once

#include "common.h"
#include "core/event.h"

namespace pokemon {

/// Calls a callback of the product before the game makes a Pokémon model.
class ModelReplacement {
  MAKE_SINGLETON(ModelReplacement)

public:
  /// Called before the game makes a Pokémon model. Change `info` to change
  /// the species, the form or the shiny state of the model.
  /// Called before the game makes a Pokémon model. Change `info` to change
  /// the species, the form or the shiny state of the model.
  core::Event<void(PokeInfo*)> on_create;

  static void Initialize();

private:
  static void CreateHook(void* model, PokeInfo* info, void* p0, void* p1,
                         void* p2, void* p3);
};

} // namespace pokemon
