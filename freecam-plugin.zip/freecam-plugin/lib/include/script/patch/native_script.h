/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file native_script.h
 * @brief Runs C++ functions as overworld scripts.
 *
 * @see docs/concepts/scripts.md
 */

#pragma once

#include "common.h"
#include "core/fixed_list.h"
#include "core/problems.h"
#include "script/constant/script.h"
#include "script/native/amx.h"
#include "script/native/engine.h"
#include "script/patch/context.h"
#include "script/patch/natives.h"
#include "system/coroutine.h"
#include "ui/log.h"

namespace script {
/**
 * @brief Runs C++ functions as overworld scripts.
 *
 * When the game starts a registered script id, the library gives the game a
 * small .amx program. This program calls one native again and again. The
 * native runs the C++ function in a coroutine:
 *
 *     halt 0            ; return address 0 (Pawn convention)
 *     main: proc
 *     loop: push.c 0    ; no parameters
 *           sysreq.c 0  ; native 0 -> NativeEntry
 *           stack 4
 *           jnz loop    ; continue while the C++ function runs
 *           zero.pri
 *           retn
 *
 * @code
 * script::NativeScript::Register(kMyScript, MyScript);
 * @endcode
 */
class NativeScript {
  MAKE_SINGLETON(NativeScript)

public:
  static constexpr u32 kMaxScripts = 256;
  static constexpr u32 kStackSize = 32 * 1024;
  static constexpr u32 kMessageCapacity = 512;
  static constexpr s32 kBorrowedScriptId = (s32)ScriptId::kDoNothing;

  bool log_activity = false; ///< true: writes the start and the end of each C++ script to the log.
  u32 run_count = 0;

  static void Initialize();

  /// Links a script id to a C++ function. 256 scripts at most.
  static bool Register(ScriptId id, Function function) {
    auto& ctx = GetInstance();
    if (function == nullptr) return false;
    if (ctx.Find(id) != nullptr) {
      core::Problems::Add(u"script %u: the id is used two times", (u32)id);
      return false;
    }
    if (ctx.entries_.IsFull()) {
      core::Problems::Add(u"script %u: more than %u C++ scripts", (u32)id,
                          kMaxScripts);
      return false;
    }
    ctx.entries_.Add(Entry{id, function});
    return true;
  }

  /// Returns true when a C++ function has this script id.
  static bool IsRegistered(ScriptId id) {
    return GetInstance().Find(id) != nullptr;
  }

  /// Returns the number of registered scripts.
  static u32 GetCount() { return GetInstance().entries_.Count(); }

  /// Returns the id of the C++ script that runs now, or ScriptId::kNone.
  static ScriptId GetCurrentId() {
    const Entry* current = GetInstance().current_;
    return current != nullptr ? current->id : ScriptId::kNone;
  }

  /// Returns the id of a registered script (index from 0 to GetCount() - 1).
  static ScriptId GetId(u32 index) {
    return GetInstance().entries_[index < kMaxScripts ? index : 0].id;
  }

  /// Gives the small .amx program to the game. core::ScriptLoader calls it.
  static bool OnLoad(void* self, const void*& buffer, u32& size) {
    auto& ctx = GetInstance();
    auto* vm = (ScriptVm*)self;
    Engine* engine = Engine::GetInstance();
    if (engine == nullptr || engine->GetCurrentVm() != vm) return false;

    ScriptDescriptor* descriptor = vm->GetDescriptor();
    if (descriptor == nullptr) return false;
    const Entry* entry = ctx.Find((ScriptId)descriptor->script_id);
    if (entry == nullptr) return false;

    if (!ctx.natives_resolved_) {
      if (!ctx.natives_.Resolve()) {
        ui::Log::Print(u"script %d: some natives are missing",
                                  descriptor->script_id);
      }
      ctx.natives_resolved_ = true;
    }

    if (ctx.IsSuspendedElsewhere(engine, vm)) {
      ui::Log::Print(u"script %d: nested C++ scripts unsupported",
                                descriptor->script_id);
      return false;
    }

    ctx.current_ = entry;
    ctx.engine_ = engine;
    ctx.vm_ = vm;
    ctx.context_.Bind(&vm->amx);
    ctx.coroutine_.Start(RunScript, &ctx);
    ctx.run_count++;
    if (ctx.log_activity) {
      ui::Log::Print(u"script %d -> C++", descriptor->script_id);
    }

    buffer = ctx.stub_;
    size = ((const AmxHeader*)ctx.stub_)->total_file_size;
    return true;
  }

private:
  struct Entry {
    ScriptId id;
    Function function;
  };

  static constexpr u32 kStubSize = 0x80;
  /// The same size as for the scripts of the game.
  static constexpr u32 kStubStackSize = 0x1000;

  const Entry* Find(ScriptId id) const {
    return entries_.Find([id](const Entry& entry) { return entry.id == id; });
  }

  bool IsSuspendedElsewhere(const Engine* engine,
                            const ScriptVm* vm) const {
    if (current_ == nullptr || coroutine_.IsFinished()) return false;
    if (engine_ != engine || vm_ == vm) return false;
    return vm_->is_loaded;
  }

  static void DescriptorSetupHook(ScriptDescriptor* descriptor,
                                  u16 zone_id, s32 script_id,
                                  void* zone_data);

  static PawnCell NativeEntry(AmxRuntime* amx, const PawnCell*) {
    auto& ctx = GetInstance();
    if (ctx.current_ == nullptr) return 0;
    if (ScriptVm::FromAmx(amx) != ctx.vm_) return 0;

    ctx.context_.Bind(amx);
    const bool alive = ctx.coroutine_.Resume();

    if (!ctx.coroutine_.IsStackHealthy()) {
      ui::Log::Print(u"script %d: stack overflow!",
                                (s32)ctx.current_->id);
    }
    if (alive) return 1;

    if (ctx.log_activity) {
      ui::Log::Print(u"script %d done (stack %u bytes)",
                                (s32)ctx.current_->id,
                                ctx.coroutine_.GetStackHighWater());
    }
    ctx.current_ = nullptr;
    ctx.vm_ = nullptr;
    return 0;
  }

  static void RunScript(void* arg) {
    auto* ctx = (NativeScript*)arg;
    ctx->current_->function(ctx->context_);
  }

  void BuildStub() {
    auto* header = (AmxHeader*)stub_;
    auto* native = (AmxSymbol*)(stub_ + sizeof(AmxHeader));
    u32 offset = sizeof(AmxHeader) + sizeof(AmxSymbol);
    auto* name_table = (u16*)(stub_ + offset);
    offset += 2 * sizeof(u16);
    const u32 code_offset = offset;
    auto* code = (u32*)(stub_ + code_offset);
    u32 n = 0;

    code[n++] = kAmxOpHalt;
    code[n++] = 0;
    const u32 main_offset = n * sizeof(u32);
    code[n++] = kAmxOpProc;
    const u32 loop_offset = n * sizeof(u32);
    code[n++] = kAmxOpPushC;
    code[n++] = 0;
    code[n++] = kAmxOpSysreqC;
    code[n++] = 0;
    code[n++] = kAmxOpStack;
    code[n++] = sizeof(u32);
    const u32 jnz_offset = n * sizeof(u32);
    code[n++] = kAmxOpJnz;
    code[n++] = (u32)((s32)loop_offset - (s32)jnz_offset);
    code[n++] = kAmxOpZeroPri;
    code[n++] = kAmxOpRetn;
    const u32 code_size = n * sizeof(u32);

    native->address = (u32)&NativeEntry;
    native->name_hash = CalcNameHash("CppScript");
    name_table[0] = 63;
    name_table[1] = 0;

    header->total_file_size = code_offset + code_size;
    header->magic_number = AMX_MAGIC;
    header->file_format_version = AMX_FILE_VERSION;
    header->required_virtual_machine_version = AMX_FILE_VERSION;
    header->flags = AMX_FLAG_SLEEP | AMX_FLAG_NOCHECKS;
    header->symbol_entry_size = AMX_SYMBOL_ENTRY_SIZE;
    header->code_section_offset = code_offset;
    header->data_section_offset = code_offset + code_size;
    header->heap_start_offset = header->data_section_offset;
    header->stack_top_offset = header->heap_start_offset + kStubStackSize;
    header->initial_instruction_pointer = main_offset;
    header->public_functions_offset = sizeof(AmxHeader);
    header->native_functions_offset = sizeof(AmxHeader);
    header->libraries_offset = sizeof(AmxHeader) +
                               sizeof(AmxSymbol);
    header->public_variables_offset = header->libraries_offset;
    header->tag_names_offset = header->libraries_offset;
    header->string_table_offset = header->libraries_offset;
    header->overlay_table_offset = header->libraries_offset;
  }

  core::FixedList<Entry, kMaxScripts> entries_;
  const Entry* current_ = nullptr;
  Engine* engine_ = nullptr;
  ScriptVm* vm_ = nullptr;
  Natives natives_ = {};
  bool natives_resolved_ = false;
  alignas(8) u8 stack_[kStackSize];
  alignas(4) u8 stub_[kStubSize];
  alignas(4) c16 message_buffer_[kMessageCapacity];
  Coroutine coroutine_{stack_, kStackSize};
  Context context_{natives_, coroutine_, message_buffer_,
                           kMessageCapacity};
};

} // namespace script
