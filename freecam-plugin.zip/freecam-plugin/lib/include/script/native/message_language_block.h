/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file message_language_block.h
 * @brief One language block of a message file.
 */

#pragma once

#include "core/types.h"

namespace script {

/// A language block of a message file. The strings follow the block.
struct MessageLanguageBlock {
  u32 size;
  u32 string_offset;
  u16 length;
  u16 user_param;
} __attribute__((packed));

} // namespace script
