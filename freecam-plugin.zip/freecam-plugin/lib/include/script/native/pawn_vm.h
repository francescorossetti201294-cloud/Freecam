/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file pawn_vm.h
 * @brief A Pawn virtual machine of the game.
 */

#pragma once

#include "core/types.h"
#include "script/native/amx.h"

namespace script {

/// The Pawn virtual machine that runs a script.
struct PawnVm {
  void* vtable; // 0x00
  AmxRuntime amx; // 0x04
  const void* buffer; // 0x7C
  u32 buffer_size; // 0x80
  void* heap; // 0x84
  s32 suspend_frames; // 0x88
  /// The result of the run. AMX_ERR_NONE when the run is complete.
  s16 execute_result; // 0x8C
  u16 is_halted; // 0x8E

  INLINE bool IsFinished() const { return execute_result == AMX_ERR_NONE; }
};

static_assert(sizeof(PawnVm) == 0x90, "PawnVm layout");

} // namespace script
