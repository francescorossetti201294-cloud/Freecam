/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file poke_info_on_action.h
 * @brief One entry of an encounter table.
 */

#pragma once

#include "core/types.h"
#include "pokemon/constant/form.h"
#include "pokemon/constant/species.h"

namespace overworld {

/// One entry of an encounter table: species, form and levels.
struct PokeInfoOnAction {
  SpeciesId species : 11;
  FormId form : 5;
  u8 min_level;
  u8 max_level;
};

static_assert(sizeof(PokeInfoOnAction) == 4,
              "PokeInfoOnAction must match the game's encounter table layout");

} // namespace overworld
