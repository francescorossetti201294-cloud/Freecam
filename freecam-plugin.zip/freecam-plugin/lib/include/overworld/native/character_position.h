/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file character_position.h
 * @brief The position of a character.
 */

#pragma once

#include "core/types.h"
#include "overworld/constant/position_kind.h"

namespace overworld {

/// The position of a character: tiles and height.
struct CharacterPosition {
  PositionKind kind;
  u16 tile_x;
  u16 tile_z;
  f32 height;
};

} // namespace overworld
