/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file camera_scroll_area.h
 * @brief The camera limits of a world layout.
 */

#pragma once

#include "core/types.h"
#include "overworld/native/camera_scroll_rect.h"

namespace overworld {

/// The rectangles where the camera moves differently (16 at most).
struct CameraScrollArea {
  static constexpr u32 kMaxRects = 16;

  u32 rect_count;
  CameraScrollRect rect[kMaxRects];
};

static_assert(sizeof(CameraScrollArea) == 0x144,
              "CameraScrollArea must match the game's camera scroll pack");

} // namespace overworld
