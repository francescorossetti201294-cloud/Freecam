/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file day_care.h
 * @brief Faster Eggs and experience at the Day Care.
 */

#pragma once

#include "common.h"

namespace overworld {

/// Makes the Eggs hatch at once, and gives the maximum experience at the Day Care.
class DayCare {
  MAKE_SINGLETON(DayCare)

public:
  bool instant_egg_hatch = false;
  bool instant_max_exp = false;

  static void PatchLoad();
  static void ApplyEggHatch(void*);
  static void ApplyMaxExp(void*);
};

} // namespace overworld
