/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file player_cheats.h
 * @brief The cheat codes of the player: Noclip and Swarm Mod.
 */

#pragma once

#include "common.h"

namespace overworld {

/// The cheat codes of the player.
struct PlayerCheats {
  MAKE_SINGLETON(PlayerCheats)
  Vec3 speed = Vec3{1, 1, 1}; ///< The speed of Noclip on each axis.
  /// The player walks through the tiles, the objects and the height steps. The
  /// map is not changed: the plugin ignores the answer of the collision check.
  bool no_collision = false;
  /// The frames that the player needs to walk one tile: the index in
  /// kStepFrames. The game uses 7 frames for the walk and 4 for the run.
  u8 walk_frames = 6;
  u8 run_frames = 3;
  f32 theta = 0.0f;
  f32 radius = 5.0f;
  f32 theta_speed = 1.0f;

  static void Initialize();
  static void SwarmMod();
  static void Noclip();

};

} // namespace overworld
