/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file trade.h
 * @brief Changes the in-game trades.
 */

#pragma once

#include "common.h"

namespace overworld {

/// Changes the in-game trades.
class Trade {
  MAKE_SINGLETON(Trade)

public:
  bool randomize_species = false; ///< true: each trade gives a random species.

  static void Initialize();

private:
  static void RandomizeSpecies(u32 index);
  static s32 TradePokemonHook(u32* p1, u32* p2);
};

} // namespace overworld
