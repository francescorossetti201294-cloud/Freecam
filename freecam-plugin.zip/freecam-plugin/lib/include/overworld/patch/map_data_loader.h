/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file map_data_loader.h
 * @brief Changes the map data when the game loads it.
 */

#pragma once

#include "common.h"

namespace overworld {
class MapData;
}

namespace overworld {

/// Changes the map data when the game loads it.
class MapDataLoader {
  MAKE_SINGLETON(MapDataLoader)

public:
  bool is_contact_enabled = true;

  static void Initialize();
  static bool LoadMapData(MapData* map_data);
};

} // namespace overworld
