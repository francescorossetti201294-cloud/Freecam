/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file text_box.h
 * @brief A text box of a 2D layout.
 */

#pragma once

#include "renderer/native/pane.h"

namespace renderer {
/// A text box of a 2D layout.
struct TextBox {
  Pane pane;
  c16* text;
  Color8 top_color;
  Color8 bottom_color;
};
} // namespace renderer