/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file type_helper.h
 * @brief Shows the effectiveness of the moves during a battle.
 */

#pragma once

#include "common.h"
#include "pokemon/constant/move.h"

namespace battle {

/// Shows the effectiveness of the moves on the top screen during a battle.
class TypeHelper {
  MAKE_SINGLETON(TypeHelper)

public:
  struct EffectivenessInfo {
    const c16* symbol;
    Color color;
  };

  /// Draws the effectiveness. plugin::DrawFrame() calls it.
  static void DrawTop();

private:
  static EffectivenessInfo GetEffectivenessInfo(u8 result);
  static void GetMoveString(MoveId move);
};
} // namespace battle
