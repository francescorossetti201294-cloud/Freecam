/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file app_layout_manager.h
 * @brief The 2D layouts of a game screen.
 */

#pragma once

#include "common.h"
#include "renderer/native/picture.h"
#include "system/address.h"
#include "ui/address.h"

namespace renderer {
struct TextBox;
}

namespace ui {

/// The 2D layouts of a game screen: its panes, text boxes and pictures.
class AppLayoutManager {
  SINGLETON(AppLayoutManager)
public:
  INLINE uptr GetSubManager() {
    return READ32((uptr)this + 4);
  }

  INLINE uptr GetToken(u32 layout_id) {
    return *(uptr*)(*(uptr*)((uptr)this + 28) + 8 * layout_id);
  }

  INLINE renderer::TextBox* GetTextBox(u32 layout_id, u32 pane_id) {
    return core::GameFunction<renderer::TextBox*(uptr, u32)>::Call(
        ui::address::kAppLayoutManagerGetTextBox, GetToken(layout_id), pane_id);
  }

  INLINE renderer::Picture* GetPicture(u32 layout_id, u32 pane_id) {
    return core::GameFunction<renderer::Picture*(uptr, u32)>::Call(
        ui::address::kAppLayoutManagerGetPicture, GetToken(layout_id), pane_id);
  }

  INLINE renderer::Pane* GetPane(u32 layout_id, u32 pane_id) {
    return core::GameFunction<renderer::Pane*(u32, u32)>::Call(
        ui::address::kAppLayoutManagerGetPane, READ32(GetToken(layout_id) + 4),
        pane_id);
  }

  void
  SetTextBoxStringValue(u32 layout_id, u32 pane_id, const c16* str, ...) {
    va_list args;
    va_start(args, str);
    core::GameFunction<void(c16*, u32, const c16*, va_list)>::Call(
        sys::address::kStdVswprintf, String::GetTmpBuf(),
        sys::address::kBufferSize, str, args);
    va_end(args);

    core::GameFunction<void(renderer::TextBox*, String*)>::Call(
        ui::address::kAppLayoutManagerSetTextBoxString,
        GetTextBox(layout_id, pane_id), String::GetTmpStr());
  }

  INLINE void SetTextBoxIntegerValue(u32 layout_id, u32 pane_id, u32 text_id,
                                     u32 value,
                                     u32 digit_count) {
    return core::GameFunction<void(AppLayoutManager*, u32, u32, u32, u32, u32,
                                   u32, u32, u32)>::Call(
        ui::address::kAppLayoutManagerSetTextBoxIntegerValue, this, layout_id,
        pane_id, text_id, value, digit_count, 0, 0, 1);
  }

  INLINE void SetTextBoxColor(u32 layout_id, u32 pane_id, Color8& top_color,
                              Color8& bottom_color) {
    return core::GameFunction<void(AppLayoutManager*, u32, u32, Color8*,
                                   Color8*)>::Call(
        ui::address::kAppLayoutManagerSetTextBoxColor, this, layout_id, pane_id,
        &top_color, &bottom_color);
  }

  INLINE void ShowPane(u32 layout_id, u32 pane_id) {
    return core::GameFunction<void(AppLayoutManager*, u32, u32, bool)>::Call(
        ui::address::kAppLayoutManagerShowPane, this, layout_id, pane_id, true);
  }

  INLINE void HidePane(u32 layout_id, u32 pane_id) {
    return core::GameFunction<void(AppLayoutManager*, u32, u32, bool)>::Call(
        ui::address::kAppLayoutManagerShowPane, this, layout_id, pane_id,
        false);
  }

  INLINE void ShowAnimation(u32 layout_id, u32 anim_id) {
    return core::GameFunction<void(AppLayoutManager*, u32, u32, bool,
                                   bool)>::Call(
        ui::address::kAppLayoutManagerShowAnimation, this, layout_id, anim_id,
        true, true);
  }

  INLINE void HideAnimation(u32 layout_id, u32 anim_id) {
    return core::GameFunction<void(AppLayoutManager*, u32, u32, bool)>::Call(
        ui::address::kAppLayoutManagerHideAnimation, this, layout_id, anim_id,
        false);
  }
};

} // namespace ui
