/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file settings.h
 * @brief The options of the game.
 */

#pragma once

#include "common.h"
#include "savedata/native/savedata.h"

namespace savedata {
/// The options of the game: text speed, battle style...
struct Settings {
  SINGLETON(Settings)

  STATIC_INLINE Settings& GetInstance() {
    return SaveData::GetInstance().GetSettings();
  }

  void* vtable;

  union {
    u32 core;

    struct {
      u32 text_speed : 2;
      u32 show_battle_animations : 1;
      u32 battle_style : 1;
      u32 language : 4;
      u32 battle_background_id : 5;
      u32 button_config_mode : 2;
      u32 prompt_save_before_net : 1;
      u32 enable_spotpass : 1;
      u32 enable_pss : 1;
      u32  : 14;
    };
  };
};
} // namespace savedata