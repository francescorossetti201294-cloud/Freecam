/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file battle_box.h
 * @brief The Battle Box.
 */

#pragma once

#include "pokemon/native/core_data.h"
#include "savedata/native/savedata.h"

namespace savedata {
/// The Battle Box: a team of six Pokémon for the link battles.
struct BattleBox {
  SINGLETON(BattleBox)

  STATIC_INLINE BattleBox& GetInstance() {
    return SaveData::GetInstance().GetBattleBox();
  }

  static constexpr u32 kMaxSlots = 6;

  void* vtable;
  pokemon::CoreData pokemons[kMaxSlots];
};
} // namespace savedata