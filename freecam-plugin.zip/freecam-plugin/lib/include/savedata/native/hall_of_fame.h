/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file hall_of_fame.h
 * @brief The Hall of Fame.
 */

#pragma once

#include "savedata/native/savedata.h"
#include "pokemon/constant/item.h"
#include "pokemon/constant/move.h"
#include "pokemon/constant/species.h"

namespace savedata {
/// The teams of the Hall of Fame.
struct HallOfFame {
  SINGLETON(HallOfFame)
  STATIC_INLINE HallOfFame& GetInstance() {
    return SaveData::GetInstance().GetHallOfFame();
  }

  struct Pokemon {
    SpeciesId species;
    ItemId item;
    MoveId moves[4];
    u32 id0;
    u32 id1;

    union {
      u32 flags;

      struct {
        u32 form : 5;
        u32 gender : 2;
        u32 level : 7;
        u32 is_shiny : 1;
        u32 has_nickname : 1;
        u32 trainer_gender : 1;
        u32 _0 : 15;
      };
    };

    c16 nickname[12];
    c16 trainer_name[12];
  };

  struct Entry {
    Pokemon pokemon[6];

    union {
      u32 flags;

      struct {
        u32 count : 14;
        u32 year : 8;
        u32 month : 4;
        u32 day : 5;
        u32 is_used : 1;
      };
    };
  };

  void* vtable;
  Entry entries[16];
};
} // namespace savedata