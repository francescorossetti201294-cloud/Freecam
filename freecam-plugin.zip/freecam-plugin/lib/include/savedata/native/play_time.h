/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file play_time.h
 * @brief The play time.
 */

#pragma once
#include "core/native/data_manager.h"

namespace savedata {
/// The play time.
struct PlayTime {
  SINGLETON(PlayTime)

  STATIC_INLINE PlayTime& GetInstance() {
    return core::DataManager::GetInstance().GetPlayTime();
  }

  void* vtable;
  u16 hour;
  u8 minute;
  u8 second;
  u32 save_flags;
};
} // namespace savedata