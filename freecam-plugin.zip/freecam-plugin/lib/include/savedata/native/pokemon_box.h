/*
 * Copyright (C) 2026  David Darras
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * @file pokemon_box.h
 * @brief The Pokémon of the PC boxes.
 */

#pragma once
#include "savedata/native/savedata.h"
#include "pokemon/native/core_data.h"

namespace savedata {
/// The Pokémon of the PC boxes.
struct PokemonBox {
  SINGLETON(PokemonBox)
  
  STATIC_INLINE PokemonBox& GetInstance() {
    return SaveData::GetInstance().GetPokemonBox();
  }

  static constexpr u32 kMaxBoxes = 31;
  static constexpr u32 kMaxSlotsPerBox = 30;

  void* vtable;

  struct {
    pokemon::CoreData pokemons[kMaxSlotsPerBox];
  } boxes[kMaxBoxes];
};
} // namespace savedata